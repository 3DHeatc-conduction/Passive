%plot h5 files

clear;close all;
path='H:\Heat_conduction\H09161\h5\';
% savepath='F:\Springer\图及数据\散射体\三维\电场\';

i=3;

path0=[path num2str(i) '.h5'];
% path1=[path num2str(i) '.mat'];
% savepath1=[savepath num2str(i) '.emf'];
% savepath2=[savepath num2str(i) '.fig'];

% load(path1);

eps = h5read(path0,'/alpha');


set(groot,'defaultLineLineWidth',1.5)
plot_h5eps(eps);
% plot_h5eps2(eps2d);
%plot_h5E(Exr,Exi,Eyr,Eyi);
% plot_h5E(fields_true_r0(:,:,:,1),fields_true_i0(:,:,:,1),fields_true_r0(:,:,:,2),fields_true_i0(:,:,:,2));
% plot_h5Ep(fields_generated_r0(:,:,:,1),fields_generated_i0(:,:,:,1),fields_generated_r0(:,:,:,2),fields_generated_i0(:,:,:,2));
% plot_h5Ee(error_r0(:,:,:,1),error_i0(:,:,:,1),error_r0(:,:,:,2),error_i0(:,:,:,2));
% saveas(gcf,savepath1);
% saveas(gcf,savepath2);