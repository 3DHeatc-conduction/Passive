function  plot_h5E(Exr,Exi,Eyr,Eyi)

Nx=32;
Ny=32;
Nz=32;
xs=1:Nx;
ys=1:Ny;
zs=1:Nz;


[x,y,z]=meshgrid(1:Nx,1:Ny,1:Nz);

 figure;
 set(gcf, 'position', [0 0 600 600]);

subplot(3,4,1)
Exr=shiftdim(Exr,1);
h=slice(x,y,z,Exr,xs,ys,zs);
set(h,'FaceColor','interp','EdgeColor','none');
camproj perspective
%colorbar;
caxis([-2,2]);
colormap(hot);
axis square
title('E_x^r');
set(gca,'FontSize',13);
set(gca,'xtick',[],'ytick',[],'ztick',[])

subplot(3,4,2)
Exi=shiftdim(Exi,1);
h=slice(x,y,z,Exi,xs,ys,zs);
set(h,'FaceColor','interp','EdgeColor','none');
camproj perspective
%colorbar;
caxis([-2,2]);
colormap(hot);
axis square
title('E_x^i');
set(gca,'FontSize',13);
set(gca,'xtick',[],'ytick',[],'ztick',[])

subplot(3,4,3)
Eyr=shiftdim(Eyr,1);
h=slice(x,y,z,Eyr,xs,ys,zs);
set(h,'FaceColor','interp','EdgeColor','none');
camproj perspective
%colorbar;
caxis([-0.5,0.5]);
colormap(hot);
axis square
title('E_y^r');
set(gca,'FontSize',13);
set(gca,'xtick',[],'ytick',[],'ztick',[])

subplot(3,4,4)
Eyi=shiftdim(Eyi,1);
h=slice(x,y,z,Eyi,xs,ys,zs);
set(h,'FaceColor','interp','EdgeColor','none');
camproj perspective
%colorbar;
caxis([-0.5,0.5]);
colormap(hot);
axis square
title('E_y^i');
set(gca,'FontSize',13);
set(gca,'xtick',[],'ytick',[],'ztick',[])


end

