load matlab.mat

tic;
for i=4:1000
    disp(i);
    num=num2str(i);
    
    x=randi(15)*0.1;
    y=randi(15)*0.1;
    z=randi(15)*0.1;
    
    l=randi([4,16])*0.1;
    w=randi([4,16])*0.1;
    h=randi([4,16])*0.1;
    pram=[x y z l w h];
    
    
    
    path=['H:\Heat_conduction\H09161\data\' num '.csv'];
    model(pram,path);
    disp('Calculation ends.')
    gen_k;
%     plot_h5eps(kmat);
    readcsvdata;
    path3=['H:\Heat_conduction\H09161\h5\' num '.h5'];
    h5create(path3,'/alpha',[32 32 32]);
    h5write(path3,'/alpha',kmat);
    
    h5create(path3,'/T',[32 32 32]);
    h5write(path3,'/T',temp);
end
toc;