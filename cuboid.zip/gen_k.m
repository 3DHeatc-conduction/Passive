
    k=zeros(32768,1);
    for j=1:32768
        if ((xyz(j,1)>=x)&&(xyz(j,1)<=x+l)&&(xyz(j,2)>=y)&&(xyz(j,2)<=y+w)&&(xyz(j,3)>=z)&&(xyz(j,3)<=z+h))
            k(j)=1;
        end
    end
    kmat=reshape(k,32,32,32);
    path1=['H:\Heat_conduction\H09161\input\' num '.mat'];
    save(path1,'kmat');
