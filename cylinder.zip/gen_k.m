
    k=zeros(32768,1);
    for j=1:32768
        if (((xyz(j,1)-x)^2+(xyz(j,2)-y)^2<=r^2) && (xyz(j,3)>=z) &&(xyz(j,3)<=z+h))
            k(j)=1;
        end
    end
    kmat=reshape(k,32,32,32);
    path1=['H:\Heat_conduction\H09181\input\' num '.mat'];
    save(path1,'kmat');
