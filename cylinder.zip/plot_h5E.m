function  plot_h5E(Exr,Exi,Eyr,Eyi)

Nx=32;
Ny=32;
Nz=32;
xs=1:Nx;
ys=1:Ny;
zs=1:Nz;


[x,y,z]=meshgrid(1:Nx,1:Ny,1:Nz);

 figure;
%  set(gcf, 'position', [0 0 600 600]);

% subplot(3,4,1)
% Exr=shiftdim(Exr,1);
h=slice(x,y,z,Exr,xs,ys,zs);
set(h,'FaceColor','interp','EdgeColor','none');
camproj perspective
%colorbar;
% caxis([-2,2]);
colormap(hot);
axis square
title('T');
set(gca,'FontSize',24);
set(gca,'xtick',[],'ytick',[],'ztick',[])




end

