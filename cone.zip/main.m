load matlab.mat

tic;
for i=11003:12000
    disp(i);
    num=num2str(i);
    
    x=randi([12,20])*0.1;
    y=randi([12,20])*0.1;
    z=randi([12,20])*0.1;
    
    r=randi([6,11])*0.1;
    h=randi([6,11])*0.1;
    rtop=randi([6,11])*0.1;
    
    pram=[x y z r h rtop];
    
    path=['H:\Heat_conduction\H09192\data\' num '.csv'];
    model(pram,path);
    disp('Calculation ends.')
    gen_k;
%     plot_h5eps(kmat);
    readcsvdata;
    path3=['H:\Heat_conduction\H09192\h5\' num '.h5'];
    h5create(path3,'/alpha',[32 32 32]);
    h5write(path3,'/alpha',kmat);
    
    h5create(path3,'/T',[32 32 32]);
    h5write(path3,'/T',temp);
end
toc;