
    k=zeros(32768,1);
    for j=1:32768
        h1=h+z-xyz(j,3);
        R=h1/h*(r-rtop)+rtop;
        if (((xyz(j,1)-x)^2+(xyz(j,2)-y)^2<=R^2) && (xyz(j,3)>=z) &&(xyz(j,3)<=z+h))
            k(j)=1;
        end
    end
    kmat=reshape(k,32,32,32);
    path1=['H:\Heat_conduction\H09192\input\' num '.mat'];
    save(path1,'kmat');
